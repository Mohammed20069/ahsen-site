function toggleModels(id) {
    const modelsDiv = document.getElementById(id);
    if (modelsDiv.classList.contains('hidden')) {
        modelsDiv.classList.remove('hidden');
    } else {
        modelsDiv.classList.add('hidden');
    }
}
const carData = {
    bmw: {
        title: "BMW M3 G80",
        image :"cosySec.webp",
        description: "La BMW M3 Competition est une voiture sportive de luxe équipée dun moteur 6 cylindres en ligne 3.0 litres biturbo. Elle développe 503 chevaux et 650 Nm de couple. Elle accélère de 0 à 100 km/h en 3.8 secondes avec la transmission intégrale xDrive, et peut atteindre une vitesse maximale de 250 km/h, ou 290 km/h avec le pack M Driver.Sa consommation moyenne est denviron 10.2 litres aux 100 kilomètres. En ville, elle consomme autour de 12.5 L/100km, et sur autoroute environ 8.8 L/100km.Elle possède une boîte automatique à 8 rapports, une suspension adaptative, et des équipements modernes d’aide à la conduite. Lintérieur est raffiné, avec des sièges sport en cuir Merino, des finitions en fibre de carbone, et un système audio haut de gamme.La M3 Competition est conçue pour offrir des sensations fortes tout en gardant un haut niveau de confort et de technologie."
    },
    mercedes: {
        title: "Mercedes-Benz G63 AMG",
        image: "download (3).jpg",
        description: "La Mercedes-Benz G63 AMG est un SUV de luxe à haute performance. Elle est équipée d’un moteur V8 biturbo de 4.0 litres qui développe 585 chevaux et 850 Nm de couple. Elle passe de 0 à 100 km/h en environ 4.5 secondes, ce qui est impressionnant pour un véhicule de ce gabarit.La vitesse maximale est limitée à 220 km/h, ou 240 km/h avec le pack AMG Driver. Malgré son poids et sa forme carrée, elle offre une tenue de route stable et une accélération puissante.La consommation moyenne est d’environ 13 à 15 litres aux 100 kilomètres, selon le style de conduite. ville, elle peut dépasser les 17 L/100km.L’intérieur est très luxueux, avec des matériaux haut de gamme, des sièges en cuir, un système audio Burmester, et toutes les dernières technologies de confort et de sécurité.La G63 AMG est un mélange unique entre le style tout-terrain classique de la Classe G et la puissance extrême des modèles AMG. C’est un véhicule qui attire l’attention et offre une expérience de conduite prestigieuse."


    },
    porsche: {
        title: "Porsche GT3 RS",
        image: "download (1).jpg",
        description: "La Porsche 911 GT3 RS est une voiture de sport extrême, conçue pour les passionnés de conduite sur piste et de sensations fortes. Elle est animée par un moteur flat-6 atmosphérique de 4,0 litres développant 518 chevaux, capable d’abattre le 0 à 100 km/h en seulement 2,7 secondes. La boîte de vitesses est une PDK à double embrayage et 7 rapports, avec une transmission aux roues arrière, offrant une précision et une réactivité exceptionnelles.Sur le plan du design, la GT3 RS se démarque avec son aileron arrière massif et son système DRS (Drag Reduction System) inspiré de la F1, qui optimise l’aérodynamisme à haute vitesse. Sa structure légère est renforcée par l'utilisation intensive de fibre de carbone, ce qui améliore l'agilité et la performance. L’intérieur est fidèle à l’esprit sportif : sièges baquets en cuir Race-Tex, finitions racing et un écran tactile de 10,9 pouces intégrant le système Porsche Track Precision pour analyser les performances sur circuit.Malgré ses performances, la consommation reste raisonnable pour une voiture de ce calibre. En cycle mixte (ville + autoroute), la GT3 RS consomme environ 13 à 15 litres aux 100 km, selon le style de conduite. En conduite sportive ou sur piste, elle peut dépasser 20 litres/100 km."
    }
};

function showCarInfo(carKey) {
    const carInfo = carData[carKey];
    document.getElementById("car-title").textContent = carInfo.title || "Car Title";
    document.getElementById("car-image").src = carInfo.image || "";
    document.getElementById("car-description").textContent = carInfo.description || "Car description goes here.";
    document.getElementById("car-info").classList.remove("hidden");
}

function hideCarInfo() {
    document.getElementById("car-info").classList.add("hidden");
}